﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using ProductService.Data;
using ProductService.Services;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Logging
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.SetMinimumLevel(LogLevel.Debug);

// CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend",
        policy => policy
            .WithOrigins("http://localhost:3000")
            .AllowAnyHeader()
            .AllowAnyMethod()
            .AllowCredentials());
});

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Database
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("No se encontró 'DefaultConnection'");
builder.Services.AddDbContext<ProductDbContext>(options =>
    options.UseNpgsql(connectionString));

// Servicios
builder.Services.AddScoped<IProductService, ProductService.Services.ProductService>();
builder.Services.AddScoped<ICategoryService, CategoryService>();

// JWT - MISMA CONFIGURACIÓN QUE AUTHSERVICE
var jwtSecret = builder.Configuration["Jwt:Secret"]
    ?? throw new InvalidOperationException("Jwt:Secret no encontrado");
var key = Encoding.UTF8.GetBytes(jwtSecret);

var issuer = builder.Configuration["Jwt:Issuer"] ?? "AuthApp";
var audience = builder.Configuration["Jwt:Audience"] ?? "AuthUsers";

Console.WriteLine($"🔧 ProductService JWT Config:");
Console.WriteLine($"🔧   Secret length: {jwtSecret.Length}");
Console.WriteLine($"🔧   Issuer: {issuer}");
Console.WriteLine($"🔧   Audience: {audience}");

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.RequireHttpsMetadata = false;
        options.SaveToken = true;

        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(key),
            ValidateIssuer = true,
            ValidIssuer = issuer,
            ValidateAudience = true,
            ValidAudience = audience,
            ValidateLifetime = true,
            ClockSkew = TimeSpan.Zero,
            RoleClaimType = ClaimTypes.Role,
            NameClaimType = ClaimTypes.Name
        };

        options.Events = new JwtBearerEvents
        {
            OnMessageReceived = context =>
            {
                var authHeader = context.Request.Headers["Authorization"].FirstOrDefault();
                Console.WriteLine($"📨 OnMessageReceived - Raw header: {authHeader}");

                if (!string.IsNullOrEmpty(authHeader) && authHeader.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
                {
                    var token = authHeader.Substring("Bearer ".Length).Trim();

                    // Limpiar token: eliminar posibles caracteres de control o espacios extras
                    token = token.Replace("\n", "").Replace("\r", "").Replace("\t", "").Trim();

                    var parts = token.Split('.');
                    Console.WriteLine($"📨 Token parts: {parts.Length}, Length: {token.Length}");

                    // Validar que tenga 3 partes y que no esté vacío
                    if (parts.Length == 3 && !string.IsNullOrEmpty(parts[0]) && !string.IsNullOrEmpty(parts[1]) && !string.IsNullOrEmpty(parts[2]))
                    {
                        // Asignar token manualmente al contexto
                        context.Token = token;
                        Console.WriteLine($"✅ Token asignado manualmente al contexto.");
                    }
                    else
                    {
                        Console.WriteLine($"❌ Token inválido después de limpiar: {token.Substring(0, Math.Min(50, token.Length))}...");
                    }
                }
                else
                {
                    Console.WriteLine($"❌ Header Authorization no encontrado o no comienza con Bearer.");
                }
                return Task.CompletedTask;
            },
            OnAuthenticationFailed = context =>
            {
                Console.WriteLine($"❌ Auth failed: {context.Exception.Message}");
                Console.WriteLine($"❌ Exception: {context.Exception.GetType().Name}");
                var header = context.Request.Headers["Authorization"].FirstOrDefault();
                Console.WriteLine($"❌ Header at failure: {header}");
                return Task.CompletedTask;
            },
            OnTokenValidated = context =>
            {
                var user = context.Principal;
                Console.WriteLine($"✅ Token validado - User: {user?.Identity?.Name}");
                var roles = user?.FindAll(ClaimTypes.Role).Select(c => c.Value);
                if (roles != null && roles.Any())
                    Console.WriteLine($"✅ Roles: {string.Join(", ", roles)}");
                return Task.CompletedTask;
            }
        };
    });

builder.Services.AddAuthorization();

var app = builder.Build();

// ORDEN: CORS -> Auth -> Controllers
app.UseCors("AllowFrontend");

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

// Crear base de datos si no existe
using (var scope = app.Services.CreateScope())
{
    var dbContext = scope.ServiceProvider.GetRequiredService<ProductDbContext>();
    dbContext.Database.EnsureCreated();
}

Console.WriteLine($"🚀 ProductService iniciado en http://localhost:5174");

app.Run();