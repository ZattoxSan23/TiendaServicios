﻿namespace AuthService.DTOs
{
    public class ChangeRoleDto
    {
        public string Role { get; set; } = null!;
    }
}
